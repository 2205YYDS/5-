
# coding: utf-8

# In[12]:




import cv2
import random
import numpy as np

def img2strimg(frame,K):
    if type(frame)!=np.ndarray:#判断图片是否为多维数组
        frame=np.array(frame)#若不是，转换为数组
    height,width,*_=frame.shape#获取图片的长宽
    frame_gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)#将图片进行颜色空间转换(BGR->Gray)
    samples=np.float32(frame_gray.reshape(-1))#1.设置np.float32类型的数据
    #K为聚类的最终数目
    criteria=(cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,10,1.0)#3.设置终止的迭代条件
    #精确度满足或迭代次数超过阈值时停止迭代，最大迭代次数为10，精确度为1.0
    flags=cv2.KMEANS_RANDOM_CENTERS#4.设置起始重心
    compactness,labels,centroids=cv2.kmeans(samples,K,None,criteria,10,flags)#设置紧密度（每个点到相应重心的平方和，标志数组，由聚类的重心组成的数组
    centroids=np.uint8(centroids)#数组转化为uint8类型用于存储图像
    # labels的数个矩心以随机顺序排列，所以需要简单处理矩心.
    centroids = centroids.flatten()#对原多维数组降维
    centroids_sorted = sorted(centroids)
    # 获得不同centroids的明暗程度，0最暗
    centroids_index = np.array([centroids_sorted.index(value) for value in centroids])

    bright = [abs((3 * i - 2 * K) / (3 * K)) for i in range(1, 1 + K)]
    bright_bound = bright.index(np.min(bright))
    shadow = [abs((3 * i - K) / (3 * K)) for i in range(1, 1 + K)]
    shadow_bound = shadow.index(np.min(shadow))

    labels = labels.flatten()
    # 将labels转变为实际的明暗程度列表，0最暗。
    labels = centroids_index[labels]
    # 列表解析，每2*2个像素挑选出一个，组成（height*width*灰）数组。
    labels_picked = [labels[rows * width:(rows + 1) * width:2] for rows in range(0, height, 2)]

    canvas = np.zeros((3 * height, 3 * width, 3), np.uint8)
    canvas.fill(255)  # 创建长宽为原图三倍的白色画布。

    # 因为 字体大小为0.45时，每个数字占6*6个像素，而白底画布为原图三倍
    # 所以 需要原图中每2*2个像素中挑取一个，在白底画布中由6*6像素大小的数字表示这个像素信息。
    y = 8
    for rows in labels_picked:
        x = 0
        for cols in rows:
            if cols <= shadow_bound:
                cv2.putText(canvas, random.choice('1234567890'),
                            (x, y), cv2.FONT_HERSHEY_PLAIN, 0.45, 1)
            elif cols <= bright_bound:
                cv2.putText(canvas,random.choice('!@#$%^&*()') , (x, y),
                            cv2.FONT_HERSHEY_PLAIN, 0.50, 0, 1)
            x += 6
        y += 6

    return canvas


if __name__ == '__main__':
    fp = r"C:/Users/Lenovo/Desktop/test.jpg"
    img = cv2.imread(fp)
    str_img = img2strimg(img,3)
    cv2.imwrite("C:/Users/Lenovo/Desktop/test2.jpg", str_img)

