import math
ls = []
num = int(input("请输入一个十进制的数："))
n = 1
while True:
    if math.pow(2,n+1)>num:
        break
    else:
        n = n + 1
while n>=0:
    if math.pow(2, n)<=num:
        ls.append(1)
        num = num - math.pow(2,n)
        n = n - 1
    else:
        ls.append(0)
        n = n - 1
print("转换结果为: ",end='')
for i in ls:
    print(i,end='')